def red(text):
    return "\033[0;31m" + text + "\033[0m"


def green(text):
    return "\033[0;32m" + text + "\033[0m"


def yellow(text):
    return "\033[0;33m" + text + "\033[0m"


def blue(text):
    return "\033[0;34m" + text + "\033[0m"
