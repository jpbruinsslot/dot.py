#####################
Release History
#####################

0.1b1 (2015-02-17)
=======================
* Added functionality for tracking files without the notion of a specific
  username

0.1b0 (9001-01-01)
=======================
* Initial beta release
